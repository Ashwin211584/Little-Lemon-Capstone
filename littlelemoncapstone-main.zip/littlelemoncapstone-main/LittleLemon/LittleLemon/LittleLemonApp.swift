//
//  LittleLemonApp.swift
//  LittleLemon
//
//  Created by Kay Khine win on 16/5/23.
//

import SwiftUI

@main
struct LittleLemonApp: App {
    var body: some Scene {
        WindowGroup {
            Onboarding()
        }
    }
}
