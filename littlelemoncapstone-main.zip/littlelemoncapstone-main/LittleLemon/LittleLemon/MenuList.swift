//
//  MenuList.swift
//  LittleLemon
//
//  Created by Kay Khine win on 16/5/23.
//

import Foundation

struct MenuList: Decodable {
    let menu: [MenuItem]
}
